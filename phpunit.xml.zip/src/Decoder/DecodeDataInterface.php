<?php namespace Hubstaff\Decoder;

interface DecodeDataInterface
{
    public function decode($data);
}
